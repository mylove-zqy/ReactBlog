import React, { Fragment, memo } from "react";
import { HeaderWrapper } from "./style";
import { Menu, Dropdown } from "antd";
import { NavLink } from "react-router-dom";
import {
  CaretUpOutlined,
  // CaretDownOutlined,
  BankOutlined,
  EditOutlined,
  BarChartOutlined,
  WechatOutlined,
  UserOutlined,
  MenuFoldOutlined,
  CaretDownOutlined,
  QqOutlined,
} from "@ant-design/icons";
import { changeLeftVisibleAction } from "../drawer/store/actionCreators";
import { changMainMoveRight } from "@/pages/main/store/actionCreators";
import { changeIsHiddenAction } from "./store/actionCreators";
import { useSelector, shallowEqual, useDispatch } from "react-redux";

export default memo(function Header(props) {
  //state
  const tabList = [
    { title: "首页", index: 0, link: "/home" },
    { title: "实战", index: 1, link: "/battle" },
    { title: "归档", index: 2, link: "/life" },
    { title: "互动", index: 3, link: "/interact" },
    { title: "关于", index: 4, link: "/about" },
  ];
  const iconList = [
    <BankOutlined />,
    <EditOutlined />,
    <BarChartOutlined />,
    <WechatOutlined />,
    <UserOutlined />,
  ];
  const menu = (
    <Menu>
      <Menu.Item>
        <QqOutlined /> QQ登录
      </Menu.Item>
    </Menu>
  );

  const menu2 = (
    <Menu>
      {tabList.map((item, index) => {
        return (
          <Fragment key={item.index}>
            <Menu.Item style={{ width: "110px" }}>
              <NavLink
                className="nav-link"
                exact
                to={item.link}
                style={{ padding: "5px  20px" }}
              >
                <span className="tab-item-icon">{iconList[item.index]}</span>
                <span>&nbsp;&nbsp;&nbsp;</span>
                <span className="tab-item-name">{item.title}</span>
              </NavLink>
            </Menu.Item>
          </Fragment>
        );
      })}
      <Menu.Item>
        <QqOutlined /> QQ登录
      </Menu.Item>
    </Menu>
  );
  //hook
  // useEffect(() => {}, []);

  //redux-hook
  const dispatch = useDispatch();
  const {
    isHidden = false,
    ThemeColor,
    fontColor,
    HoverColor,
    visible,
    moveRight,
  } = useSelector(
    (state) => ({
      isHidden: state.getIn(["header", "isHidden"]),
      ThemeColor: state.getIn(["header", "ThemeColor"]),
      fontColor: state.getIn(["header", "fontColor"]),
      HoverColor: state.getIn(["header", "HoverColor"]),
      visible: state.getIn(["drawer", "visible"]),
      moveRight: state.getIn(["main", "moveRight"]),
    }),
    shallowEqual
  );

  //handle
  const openDrawer = () => {
    dispatch(changeLeftVisibleAction(!visible));
  };

  //监听窗口滚动
  window.addEventListener("scroll", () => {
    const scrollTop =
      document.documentElement.scrollTop || document.body.scrollTop;
    if (!isHidden && parseInt(scrollTop) >= 100) {
      dispatch(changeIsHiddenAction(!isHidden));
    }
    if (isHidden && parseInt(scrollTop) < 100) {
      dispatch(changeIsHiddenAction(!isHidden));
    }
  });
  // console.log(ThemeColor);
  return (
    <HeaderWrapper
      className="flex-wrap"
      ThemeColor={ThemeColor}
      isHidden={isHidden}
      HoverColor={HoverColor}
      fontColor={fontColor}
    >
      <div className="header-box flex-wrap">
        <div className="header-left">
          <div
            className="left-menu"
            style={{ cursor: "pointer", color: "white" }}
            onClick={() => openDrawer()}
          >
            <MenuFoldOutlined />
          </div>
          <div className="blog-info">
            <div
              className="blog-title"
              title="Loneliness后台管理系统"
              onClick={() => window.open("http://47.98.47.212/dist")}
            >
              Loneliness
            </div>
            <div className="some-sentence">万水千山，你愿意陪我一起看吗</div>
          </div>
          <div className="right-menu">
            <Dropdown overlay={menu2} placement="bottomCenter">
              <span
                className="icon-drop"
                style={{
                  color: HoverColor === "white" ? HoverColor : "",
                  marginRight: "18px",
                }}
              >
                <CaretUpOutlined
                  className="up"
                  style={{
                    padding: "18px",
                    top: 0,
                    marginRight: "18px",
                    position: "absolute",
                  }}
                ></CaretUpOutlined>
                <CaretDownOutlined
                  style={{
                    padding: "18px",
                    marginRight: "18px",
                    top: 0,
                    position: "absolute",
                  }}
                  className="down"
                />
              </span>
            </Dropdown>
          </div>
        </div>
        <div className="header-right">
          <div className="tab-list">
            {tabList.map((item, index) => {
              return (
                <div className="tab-item" key={item.index}>
                  <NavLink
                    className="nav-link"
                    exact
                    to={item.link}
                    onClick={() => dispatch(changMainMoveRight(false))}
                  >
                    <span className="tab-item-icon">
                      {iconList[item.index]}
                    </span>
                    <span className="tab-item-name">{item.title}</span>
                  </NavLink>
                </div>
              );
            })}
            <Dropdown overlay={menu} placement="bottomCenter">
              <span className="icon-drop">
                <CaretUpOutlined
                  className="up"
                  style={{
                    padding: "18px",
                    top: 0,
                    position: "absolute",
                  }}
                ></CaretUpOutlined>
                <CaretDownOutlined
                  style={{
                    padding: "18px",
                    top: 0,
                    position: "absolute",
                  }}
                  className="down"
                />
              </span>
            </Dropdown>
          </div>
        </div>
      </div>
    </HeaderWrapper>
  );
});
// export default (Header);
