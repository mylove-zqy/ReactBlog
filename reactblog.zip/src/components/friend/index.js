import React, { memo } from 'react'

export default memo(function index() {
  return (
    <div>
      
    </div>
  )
})
