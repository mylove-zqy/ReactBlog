import Item from "antd/lib/list/Item";
import React, { memo } from "react";
import { TagItemWrap } from "./style";
import { changeHomePageAction } from "@/pages/home/store/actionCreators";
import { useDispatch } from "react-redux";
export default memo(function TagItem(props) {
  const { tag } = props;
  const fontColor=props.color
  // console.log(fontColor);
  const dispatch=useDispatch()
  //handle
  const handleTagClick =()=>{
    console.log(tag);
    if(tag.tag_id==-1){
      console.log(props);
      props.history.push("/home")
      dispatch(changeHomePageAction(1))
    }
  }
  return (
    <TagItemWrap color={tag.tag_color}  fontColor={fontColor}>
      <span className="tag_name" onClick={()=>handleTagClick()} >
        {tag.tag_name}
        <span style={{ marginLeft: "4px" }}>{tag.count}</span>
      </span>
      <span className="triangle"></span>
    </TagItemWrap>
  );
});
