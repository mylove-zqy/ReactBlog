//改变歌曲详情
export const CHANGE_CURRENT_SONG = "CHANGE_CURRENT_SONG";

//改变当前的歌词index
export const CHANGE_CURRENT_INDEX = "CHANGE_CURRENT_INDEX";

//改变歌词列表
export const CHANGE_LYRIC_LIST = "CHANGE_LYRIC_LIST";

//改变歌单
export const CHANGE_SONG_LIST = "CHANGE_SONG_LIST";
