//改变路由Loading状态
export const CHANGE_MAIN_LOADING ="CHANGE_MAIN_LOADING"
//改变scrollTop
export const CHANGE_MAIN_SCROLL_TOP="CHANGE_MAIN_SCROLL_TOP"
//改变右边栏的动画状态
export const CHANGE_MAIN_MOVE_RIGHT="CHANGE_MAIN_MOVE_RIGHT"