import styled from "styled-components";

export const RightBarWrapper = styled.div`

`;
