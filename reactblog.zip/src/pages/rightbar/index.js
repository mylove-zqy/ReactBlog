import React, { memo } from "react";
import { RightBarWrapper } from "./style";
import TopInfo from "./c-cpns/topInfo";
import Tags from '@/components/tags'
import { getRightTagsAction } from "./store/actionCreators";
import { shallowEqual, useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
export default memo(function RightBar() {
  //hooks
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getRightTagsAction());
  }, [dispatch]);


  return (
    <RightBarWrapper>
      <TopInfo></TopInfo>
      <Tags color="black"></Tags>
    </RightBarWrapper>
  );
});
