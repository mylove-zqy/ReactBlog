import styled from 'styled-components'

export const AboutWrap=styled.div`
background-color:white;
.markdown-body{
  padding:5px 5px;
}
`