import request from "./index";

export function getHomeArticles(limit, page, tag_id) {
  if (tag_id == -1) {
    return request({
      url: "/article/get_articles",
      params: {
        limit,
        page,
        type: 1,
      },
    });
  }
}
